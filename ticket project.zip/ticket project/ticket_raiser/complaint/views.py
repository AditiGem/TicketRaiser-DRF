from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from .models import Complaint
from .serializers import ComplaintSerializer
from django.views.decorators.cache import cache_page
from django.utils.decorators import method_decorator
from django.core.cache import cache

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def complaint_list(request):

    if request.method == 'GET':
        cache_key = "complaint_list"
        cached_data = cache.get(cache_key)
        if cached_data:
            return Response(cached_data)
    
        complaints = Complaint.objects.all()
        category = request.query_params.get('category')
        status = request.query_params.get('status')
        search = request.query_params.get('search')
        ordering = request.query_params.get('ordering')

        if category:
            complaints = complaints.filter(category=category)
        if status:
            complaints = complaints.filter(status=status)
        if search:
            complaints = complaints.filter(title__icontains=search)
        if ordering:
            complaints = complaints.order_by(ordering)

        paginator = PageNumberPagination()
        paginator.page_size = 2
        page = paginator.paginate_queryset(complaints, request)
        serializer = ComplaintSerializer(page, many=True)
        response = paginator.get_paginated_response(serializer.data)
        cache.set(cache_key, response.data, timeout=60)
        return response
    
    if request.method == 'POST':
        serializer = ComplaintSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            cache.delete("complaint_list")
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@permission_classes([IsAuthenticated])
def complaint_detail(request, id):

    try:
        complaint = Complaint.objects.get(id=id)
    except Complaint.DoesNotExist:
        return Response({'error': 'Complaint not found'}, status=404)

    if request.method == 'GET':
        serializer = ComplaintSerializer(complaint)
        return Response(serializer.data)

    if request.method == 'PUT':
        serializer = ComplaintSerializer(complaint, data=request.data)
        if serializer.is_valid():
            serializer.save()
            cache.delete("complaint_list")
            return Response(serializer.data)
        return Response(serializer.errors, status=400)

    if request.method == 'PATCH':
        serializer = ComplaintSerializer(complaint, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            cache.delete("complaint_list")
            return Response(serializer.data)
        return Response(serializer.errors, status=400)

    if request.method == 'DELETE':
        complaint.delete()
        cache.delete("complaint_list")
        return Response({'message': 'Complaint deleted'})